# openai-kafka-iot
 
[AdTech using SingleStoreDB, Kafka and Metabase](https://medium.com/@VeryFatBoy/adtech-using-singlestoredb-kafka-and-metabase-c657659bc079)